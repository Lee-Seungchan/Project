package com.study.review;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("com.study.model.ReplyServiceImpl")
public class ReviewServiceImpl implements ReviewService {

  @Autowired
  private ReviewMapper mapper;
  
  public int create(ReviewDTO reviewDTO) {
    // TODO Auto-generated method stub
    return mapper.create(reviewDTO);
  }

  
  public List<ReviewDTO> list(Map map) {
    // TODO Auto-generated method stub
    return mapper.list(map);
  }

  
  public ReviewDTO read(int rnum) {
    // TODO Auto-generated method stub
    return mapper.read(rnum);
  }

  
  public int update(ReviewDTO reviewDTO) {
    // TODO Auto-generated method stub
    return mapper.update(reviewDTO);
  }

  
  public int delete(int rnum) {
    // TODO Auto-generated method stub
    return mapper.delete(rnum);
  }

  
  public int total(int contentsno) {
    // TODO Auto-generated method stub
    return mapper.total(contentsno);
  }

}
