$(function(){
	$("#find_ID").click(function(){
		loginCheck($("#mname").val(),$("#email").val())
			.then(text => alert(text))
			.catch(console.log);
	});
	
	$("#find_PW").click(function(){
		loginCheck2($("#id").val(),$("#email").val())
			.then(text => alert(text))
			.catch(console.log);
	});
	
});

function loginCheck(mname, email){
	return fetch(`/findID?mname=${mname}&email=${email}`)
			.then(response => response.text())
			.catch(console.log)
}

function loginCheck2(id, email){
	return fetch(`/findPW?id=${id}&email=${email}`)
			.then(response => response.text())
			.catch(console.log)
}